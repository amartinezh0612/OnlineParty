<?php echo e($slot); ?>

<?php /**PATH C:\laragon\www\proyectoingenielectricasoft\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>