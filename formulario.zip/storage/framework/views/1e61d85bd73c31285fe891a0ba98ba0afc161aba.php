<div class="modal fade modal-slide-in-right" aria-hidden="true" role="dialog" tabindex="-1" id="modal-estado-<?php echo e($solic->id_solicitud_servicio); ?>" data-backdrop="false">
    <form class="needs-validation" novalidate method="POST" action="<?php echo e(route('solicitud_servicios.update', $solic->id_solicitud_servicio)); ?>">
        <?php echo method_field('PUT'); ?>

        <?php echo csrf_field(); ?>
        <br>
        <br>
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Actualizar Estado</h4>
                </div>
                <div class="modal-body">
                <input type="hidden" name="id_usuario" value="<?php echo e($solic->id_usuario); ?>" required>
                <input type="hidden" name="id_empleado" value="<?php echo e($solic->id_empleado); ?>" required>
                <input type="hidden" name="servicios" value="<?php echo e($solic->id_servicio); ?>" required>
                <input type="hidden" name="costo_servicio" value="<?php echo e($solic->costo_servicio); ?>" required>
                <input type="hidden" name="fecha_solicitud" value="<?php echo e($solic->fecha_solicitud); ?>" required>
                <input type="hidden" name="fecha_inicio" value="<?php echo e($solic->fecha_inicio); ?>" required>
                <input type="hidden" name="fecha_terminacion" value="<?php echo e($solic->fecha_terminacion); ?>" required>
                <input type="hidden" name="contacto" value="<?php echo e($solic->contacto); ?>" required>
                <input type="hidden" name="direccion_servicio" value="<?php echo e($solic->direccion_servicio); ?>" required>
                <input type="hidden" name="telefono_servicio" value="<?php echo e($solic->telefono_servicio); ?>" required>
                <input type="hidden" name="fecha_pago" value="<?php echo e($solic->fecha_pago); ?>" required>
                <select type="text" class="form-control" name="estado">
                        <option><?php echo e($solic->estado); ?></option>
                        <?php if($solic->estado=="Pendiente"): ?>
                        <option>En Ejecución</option>
                        <option>Finalizado</option>
                        <?php elseif($solic->estado=="En Ejecución"): ?>
                        <option>Pendiente</option>
                        <option>Finalizado</option>
                        <?php else: ?>
                        <option>Pendiente</option>
                        <option>En Ejecición</option>
                        <?php endif; ?>
                    </select>
                </div>

                <div class="modal-footer">
                    <button type="button" class="mb-2 mr-2 border-0 btn-transition btn btn-outline-primary" data-dismiss="modal">Cerrar</button>
                    <button type="submit" class="mb-2 mr-2 border-0 btn-transition btn btn-outline-success">Confirmar</button>
                </div>
            </div>
        </div>
    </form>
</div><?php /**PATH C:\laragon\www\proyectoingenielectricasoft\resources\views/solicitud_servicios/modal.blade.php ENDPATH**/ ?>