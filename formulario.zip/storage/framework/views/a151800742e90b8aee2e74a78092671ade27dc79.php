<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<link rel="stylesheet" href="../../resources/views/auth/style-resetpass.css">
<!------ Include the above in your HEAD tag ---------->

<?php $__env->startSection('content'); ?>
<div class="card-body">
<form method="POST" action="<?php echo e(route('password.email')); ?>">
 <?php echo csrf_field(); ?>
 <br>
 <br>
 <br>
 <div class="login-wrap">
    <div class="login-html">
        <input id="tab-1" type="radio" name="tab" class="sign-in card-header" checked><label for="tab-1" class="tab"><?php echo e(__('Restablecer Contraseña')); ?></label>
        <input id="tab-2" type="radio" name="tab" class="for-pwd"><label for="tab-2" class="tab"></label>
        <div class="login-form">
            <div class="sign-in-htm">
                <div class="group">
                    <label for="email" class="label"><?php echo e(__('Correo Electrónico')); ?></label>
                    <div>
                       <input id="email" type="email" class="input form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"  placeholder="Correo Electrónico" name="email" value="<?php echo e(old('email')); ?>" required>
                                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                     </div>
                </div>
                <div class="group">
                    <input type="submit" class="button" value="<?php echo e(__('Restablecer Contraseña')); ?>">
                </div>                
                <div class="hr"></div>
            </div>
        </div>
    </div>
</div>
</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\proyectoingenielectricasoft\resources\views/auth/passwords/email.blade.php ENDPATH**/ ?>