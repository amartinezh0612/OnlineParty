<!DOCTYPE>
<html>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>Reporte de </title>
<style>
    body {
        /*position: relative;*/
        /*width: 16cm;  */
        /*height: 29.7cm; */
        /*margin: 0 auto; */
        /*color: #555555;*/
        /*background: #FFFFFF; */
        font-family: Arial, sans-serif;
        font-size: 14px;
        /*font-family: SourceSansPro;*/
    }


    #datos {
        float: left;
        margin-top: 0%;
        margin-left: 2%;
        margin-right: 2%;
        /*text-align: justify;*/
    }

    #encabezado {
        text-align: center;
        margin-left: 35%;
        margin-right: 35%;
        font-size: 15px;
    }

    #fact {
        /*position: relative;*/
        float: right;
        margin-top: 2%;
        margin-left: 2%;
        margin-right: 2%;
        font-size: 20px;
        background: #33AFFF;
    }

    section {
        clear: left;
    }

    #cliente {
        text-align: left;
    }

    #faproveedor {
        width: 40%;
        border-collapse: collapse;
        border-spacing: 0;
        margin-bottom: 15px;
    }

    #fac,
    #fv,
    #fa {
        color: #FFFFFF;
        font-size: 15px;
    }

    #faproveedor thead {
        padding: 20px;
        background: #33AFFF;
        text-align: left;
        border-bottom: 1px solid #FFFFFF;
    }

    #facproveedor {
        width: 100%;
        border-collapse: collapse;
        border-spacing: 0;
        margin-bottom: 15px;
    }

    #facproveedor thead {
        padding: 20px;
        background: #33AFFF;
        text-align: center;
        border-bottom: 1px solid #FFFFFF;
    }

    #facproducto {
        width: 100%;
        border-collapse: collapse;
        border-spacing: 0;
        margin-bottom: 15px;
    }

    #facproducto thead {
        padding: 20px;
        background: #33AFFF;
        text-align: center;
        border-bottom: 1px solid #FFFFFF;
    }

</style>

<body>
    <?php $__currentLoopData = $pedidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ped): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <header>
       
            <table id="datos">
                <thead>
                    <tr>
                        <th id="">DATOS DEL PROVEEDOR</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th>
                            <p id="proveedor">
                                Nombre: <?php echo e($ped->proveedor); ?> <br>
                                Teléfono: <?php echo e($ped->telefono); ?> <br>
                    </tr>
                </tbody>
            </table>
        </div>
        <div align="text-left" id="logo">
                <img  src=<?php echo e(asset('images/logo-inverse.png')); ?> alt="" id="imagen" align="center">
            </div>
        <div>
    </header>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <br>

    <br>
    <section>
        <div>
            <table id="facproveedor">
            <thead>
                    <tr id="fa">
                        <th>PROVEEDOR</th>
                        <th>FECHA ELABORACION</th>
                        <th>FECHA INICIO PEDIDO</th>
                        <th>FECHA FINAL PEDIDO</th>
                        <th>TIPO</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $pedidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ped): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($ped->proveedor); ?></td>
                        <td><?php echo e($ped->fecha_elaboracion); ?></td>
                        <td><?php echo e($ped->fecha_inicio_pedido); ?></td>
                        <td><?php echo e($ped->fecha_final_pedido); ?></td>
                        <td><?php echo e($ped->tipo_movimiento); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </section>
    <br>
    <section>
        <div>
            <table id="facproducto">
                <thead>
                    <tr id="fa">
                        <th>CANTIDAD</th>
                        <th>PRODUCTO</th>
                        <th>PRECIO PRODUCTO</th>
                        <!--<th>CANTIDAD*PRECIO</th>-->
                        <th>SUBTOTAL (USD$)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $detalle_pedidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $det): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($det->cantidad); ?></td>
                        <td><?php echo e($det->producto); ?></td>
                        <td>$<?php echo e($det->costo); ?></td>
                        <!--<td>$<?php echo e($det->cantidad*$det->precio); ?></td>-->
                        <td>$<?php echo e(number_format($det->cantidad*$det->costo,2)); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                <?php $__currentLoopData = $pedidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ped): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                           <th colspan="3"><p align="right">TOTAL:</p></th>
                            <td><p align="right">$<?php echo e(number_format($ped->monto_total)); ?><p></td>
                        </tr>
                        <tr>
                           <th  colspan="3"><p align="right">TOTAL PAGAR:</p></th>
                            <td><p align="right">$ <?php echo e(number_format($ped->monto_total)); ?></p></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tfoot>
            </table>
        </div>
    </section>
    <br>
    <br>
    <footer>
        <!--puedes poner un mensaje aqui-->
        <div id="datos">
            <p id="encabezado">
                <b>Ingenielectricasoft</b><br><br>Telefono:(+00)123456799<br>Email:ingenielectricasoft@gmail.com
            </p>
        </div>
    </footer>
</body>

</html>
<?php /**PATH C:\laragon\www\proyectoingenielectricasoft\resources\views/pdf/pedidos.blade.php ENDPATH**/ ?>