<div class="modal fade modal-slide-in-right" aria-hidden="true" role="dialog" tabindex="-1"
    id="modal-delete-<?php echo e($usu->id_usuario); ?>" data-backdrop="false">
    <?php echo e(Form::Open(array('action'=>array('UsuariosController@destroy',$usu->id_usuario),'method'=>'delete'))); ?>

    <br>
    <br>
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Eliminar Usuario</h4>
            </div>
            <div class="modal-body">
                <p>Está seguro que desea eliminar el Usuario?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="mb-2 mr-2 border-0 btn-transition btn btn-outline-primary"
                    data-dismiss="modal">Cerrar</button>
                <button type="submit"
                    class="mb-2 mr-2 border-0 btn-transition btn btn-outline-success">Confirmar</button>
            </div>
        </div>
    </div>
    <?php echo e(Form::Close()); ?>

</div>

<div class="modal fade modal-slide-in-right" aria-hidden="true" role="dialog" tabindex="-1"  data-backdrop="false">
    <form class="needs-validation" novalidate method="POST" action="<?php echo e(route('usuarios.update', $usu->id_usuario)); ?>">
        <?php echo method_field('PUT'); ?>

        <?php echo csrf_field(); ?>
        <br>
        <br>
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Actualizar Usuario</h4>
                </div>
                
                <div class="modal fade modal-slide-in-right" aria-hidden="true" role="dialog" tabindex="-1" data-backdrop="false"
                      id="modal-vista">
                <input type="hidden" name="id_usuario" value="<?php echo e($usu->id_usuario); ?>" required>
                <input type="hidden" name="nombre_completo" value="<?php echo e($usu->nombre_completo); ?>" required>
                <input type="hidden" name="correo_electronico" value="<?php echo e($usu->correo_electronico); ?>" required>
                <input type="hidden" name="telefono" value="<?php echo e($usu->telefono); ?>" required>
                <input type="hidden" name="fecha_llamada" value="<?php echo e($usu->fecha_llamada); ?>" required>
                <input type="hidden" name="ciudad" value="<?php echo e($usu->ciudad); ?>" required>
                <input type="hidden" name="motivo_celebracion" value="<?php echo e($usu->motivo_celebracion); ?>" required>
                <input type="hidden" name="fecha_evento" value="<?php echo e($usu->fecha_evento); ?>" required>
                <input type="hidden" name="numero_invitado" value="<?php echo e($usu->numero_invitado); ?>" required>
                <input type="hidden" name="rango_edad_inv" value="<?php echo e($usu->rango_edad_inv); ?>" required>
                <input type="hidden" name="duracion" value="<?php echo e($usu->duracion); ?>" required>
                <input type="hidden" name="nombre_anfitrion" value="<?php echo e($usu->nombre_anfitrion); ?>" required>
                <input type="hidden" name="edad_anfitrion" value="<?php echo e($usu->edad_anfitrion); ?>" required>
                <input type="hidden" name="nombre" value="<?php echo e($usu->nombre); ?>" required>
                <input type="hidden" name="comunicado" value="<?php echo e($usu->comunicado); ?>" required>
                <input type="hidden" name="nombre_asesor" value="<?php echo e($usu->nombre_asesor); ?>" required>
                <input type="hidden" name="observacion" value="<?php echo e($usu->observacion); ?>" required>
                </div>
               

                <div class="modal-footer">
                    <button type="button" class="mb-2 mr-2 border-0 btn-transition btn btn-outline-primary" data-dismiss="modal">Cerrar</button>
                </div>
            </div>
        </div>
    </form>
</div><?php /**PATH C:\laragon\www\formulario\resources\views/usuarios/modal.blade.php ENDPATH**/ ?>