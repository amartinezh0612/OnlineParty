<?php $__env->startSection('contenido'); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\formulario\resources\views/home.blade.php ENDPATH**/ ?>