<div class="modal fade modal-slide-in-right" aria-hidden="true" role="dialog" tabindex="-1"
    id="modal-delete-<?php echo e($ser->id_servicio); ?>" data-backdrop="false">
    <?php echo e(Form::Open(array('action'=>array('ServiciosController@destroy',$ser->id_servicio),'method'=>'delete'))); ?>

    <br>
    <br>
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Eliminar Servicio</h4>
            </div>
            <div class="modal-body">
                <p>Está seguro que desea eliminar el registro?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="mb-2 mr-2 border-0 btn-transition btn btn-outline-primary"
                    data-dismiss="modal">Cerrar</button>
                <button type="submit"
                    class="mb-2 mr-2 border-0 btn-transition btn btn-outline-success">Confirmar</button>
            </div>
        </div>
    </div>
    <?php echo e(Form::Close()); ?>

</div>

<div class="modal fade modal-slide-in-right" aria-hidden="true" role="dialog" tabindex="-1" id="modal-estado-<?php echo e($ser->id_servicio); ?>" data-backdrop="false">
    <form class="needs-validation" novalidate method="POST" action="<?php echo e(route('servicios.update', $ser->id_servicio)); ?>">
        <?php echo method_field('PUT'); ?>

        <?php echo csrf_field(); ?>
        <br>
        <br>
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Actualizar Estado</h4>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="servicio" class="form-control" value="<?php echo e($ser->servicio); ?>" required>
                    <input type="hidden" name="costo_servicio" class="form-control" value="<?php echo e($ser->costo_servicio); ?>" required>
                    <?php if($ser->estado=="Activo"): ?>
                    <p>Seguro que desea cambiar el estado a "Inactivo"</p>
                    <input type="hidden" name="estado" value="Inactivo">
                    <?php else: ?>
                    <p>Seguro que desea cambiar el estado a "Activo"</p>
                    <input type="hidden" name="estado" value="Activo">
                    <?php endif; ?>
                </div>

                <div class="modal-footer">
                    <button type="button" class="mb-2 mr-2 border-0 btn-transition btn btn-outline-primary" data-dismiss="modal">Cerrar</button>
                    <button type="submit" class="mb-2 mr-2 border-0 btn-transition btn btn-outline-success">Confirmar</button>
                </div>
            </div>
        </div>
    </form>
</div>
<?php /**PATH C:\laragon\www\proyectoingenielectricasoft\resources\views/servicios/modal.blade.php ENDPATH**/ ?>