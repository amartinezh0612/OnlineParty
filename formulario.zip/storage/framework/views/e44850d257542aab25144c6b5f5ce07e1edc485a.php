<h2>Hola Administrador,</h2>
Acabas de resivir un mensaje de : <?php echo e($name); ?>

con los siguientes detalles:
<b>Nombre:</b> <?php echo e($name); ?>

<b>correo:</b> <?php echo e($email); ?>

<b>Telefono:</b> <?php echo e($phone_number); ?>

<b>Asunto:</b> <?php echo e($subject); ?>

<b>Mensaje:</b> <?php echo e($user_message); ?><?php /**PATH C:\laragon\www\proyectoingenielectricasoft\resources\views/contact_email.blade.php ENDPATH**/ ?>